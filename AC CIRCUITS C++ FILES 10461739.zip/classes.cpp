//A.C. Analogue circuits; OOP C++; Paul Vautravers
//classes.cpp 
//contains implementation of class functions

//C++ standard library headers
#include<complex>
#include<iostream>
#include<vector>
#include<string>
#include<cmath>
#include<sstream>
#include<iomanip>
#include<numeric>
#include<math.h>
#include<algorithm>
#include<utility>
#include<map>
//header files created for this program
#include "global_functions.h"
#include "classes.h"

void component::print_component_information() {
    print_line();
    print_line();
    std::cout << "Component symbol: " << *this << std::endl;
    std::cout << "Component magnitude of impedance: " << get_magnitude_impedance() << " Ohms" << std::endl;
    std::cout << "Component phase shift: " << get_phase_impedance() << " Radians" << std::endl;
    print_line();
    print_line();
}

void component::set_connection_type(int conn_type)
//function to set connection type of component 
{
    connection_type = conn_type;
    //incoming components have name adjusted by "-" prefix to indicate coming in to node
    if (conn_type < 0) {
        set_name("-" + get_name());
    }
}

void resistor::set_frequency(double frequency_input)
//override of virtual set frequency for resistors
{
    frequency = frequency_input;
    impedance = std::complex<double>(reactance, 0);
}

void capacitor::set_frequency(double frequency_input)
//override of virtual set frequency for capacitors
{
    frequency = frequency_input;
    impedance = std::complex<double>(0, -1. / (frequency * reactance));
}

void inductor::set_frequency(double frequency_input) 
//override of virtual set frequency for inductors
{
    frequency = frequency_input;
    impedance = std::complex<double>(0, (frequency * reactance));
}

std::ostream& operator << (std::ostream& out, const component& other_component)
//simple overload of outstream to output components by their name
{
    out << other_component.component_name;
    return out;
}

size_t find_max_width(const matrix& other_matrix)
//function to find max required width of elements to nicely format component matrices in the terminal
{
    std::string matrix_element;
    std::ostringstream string_stream_matrix_element;
    size_t width{};
    for (size_t i{ 1 }; i <= other_matrix.m_rows; i++) {
        for (size_t j{ 1 }; j <= other_matrix.n_columns; j++) {
            //element set to zero if there is no edge weighting
            if (other_matrix.matrix_data[(j - 1) + (i - 1) * other_matrix.n_columns] == nullptr) {
                matrix_element = "0";
            } else {
                //matrix element name extracted and inserted into stringstream
                matrix_element = other_matrix.matrix_data[(j - 1) + (i - 1) * other_matrix.n_columns]->get_name();
                string_stream_matrix_element << matrix_element;
                //updates width if new matrix element is greater than existing width
                if (string_stream_matrix_element.str().length() > width) {
                    width = string_stream_matrix_element.str().length();
                    string_stream_matrix_element.str("");
                }
            }
        }
    }
    return width;
}

std::ostream& operator << (std::ostream& out, const matrix& other_matrix)
//overload of ostream to output matrices in an appropriate fashion
{
    size_t ideal_width{ find_max_width(other_matrix) };
    //lambda function to account for initial parallel matrices being too tight for the edge labels
    //only used here 
    auto check_min_width = [](int n)
    {
        return (n < 2) ? 2 : n;
    };
    //loop over the columns before outputting actual elements, to set the edge labels
    for (size_t j{ 1 }; j <= other_matrix.n_columns; j++) {
        if (j == 1) {
            out << std::setw(static_cast<std::streamsize>(check_min_width(ideal_width)) + 2) << "e" << j;
        } else {
            out << std::setw(check_min_width(ideal_width)) << "e" << j;
        }
    }
    out << std::endl;
    //iterate through matrix elements, using find width and check_min_width to output matrix in readable manner
    for (size_t i{ 1 }; i <= other_matrix.m_rows; i++) {
        out << "n" << i << "|";
        for (size_t j{ 1 }; j <= other_matrix.n_columns; j++) {
            if (other_matrix.matrix_data[(j - 1) + (i - 1) * other_matrix.n_columns] == nullptr) {
                out << std::setw(check_min_width(ideal_width)) << "0" << " ";
            } else {
                out << std::setw(check_min_width(ideal_width)) << *(other_matrix.matrix_data[(j - 1) + (i - 1) * other_matrix.n_columns]) << " ";
            }
        }
        out << "|" << std::endl;
    }
    return out;
}

matrix::matrix(const size_t rows_in, const size_t columns_in)
//parameterised constructor without data input, values set to zero
{
    const int invalid_matrix_error(1);
    //throw catch to avoid matrices with invalid dimensions
    try {
        if (rows_in < 1 || columns_in < 1) {
            throw(invalid_matrix_error);
        }
    }
    catch (int error_flag) {
        if (error_flag == invalid_matrix_error) {
            std::cout << "Error: trying to declare a matrix with rows or columns < 1" << std::endl;
        }
    }
    m_rows = rows_in;
    n_columns = columns_in;
    const size_t size{ length() };
    //initialise data to array of base class component pointers, set to null
    matrix_data = new component * [size] {nullptr};
}

matrix& matrix::operator=(matrix&& other_matrix) noexcept
// Move assignment operator
{
    //avoid self assignment 
    if (this == &other_matrix) {
        return *this;
    }
    delete[] matrix_data;
    matrix_data = other_matrix.matrix_data;
    m_rows = other_matrix.m_rows;
    n_columns = other_matrix.n_columns;
    other_matrix.matrix_data = nullptr;
    other_matrix.m_rows = 0;
    other_matrix.n_columns = 0;
    return *this;
}

circuit::~circuit() 
//destructor for circuit class that deletes components in library
{
    for (auto component_iterator = component_library.begin();
        component_iterator < component_library.end();
        ++component_iterator) {
        delete* component_iterator;
    }
    component_library.clear();
}

void circuit::set_default_library() 
//simple function to set a default library for the circuit
{
    component_library.push_back(new resistor{ 1.,"R1" });
    component_library.push_back(new resistor{ 2.5 ,"R2" });
    component_library.push_back(new resistor{ 5,"R3" });
    component_library.push_back(new capacitor{ 0.1,"C1" });
    component_library.push_back(new capacitor{ 0.25,"C2" });
    component_library.push_back(new capacitor{ 0.5,"C3" });
    component_library.push_back(new inductor{ 0.1,"L1" });
    component_library.push_back(new inductor{ 0.25,"L2" });
    component_library.push_back(new inductor{ 0.5,"L3" });
}

void circuit::set_total_impedance() 
//function to iterate through incidence matrix and compute total impedance
{
    std::complex<double> temp_impedance;
    size_t component_count{ 0 };
    for (size_t i{ 1 }; i <= node_count; i++) {
        std::vector<component*> node_component_vector;
        for (size_t j{ 1 }; j <= edge_count; j++) {
            //add outgoing components to vector of components
            if ((circuit_incidence_matrix.matrix_data[(i - 1) * edge_count + (j - 1)]) != nullptr && 
                (circuit_incidence_matrix.matrix_data[(i - 1) * edge_count + (j - 1)])->get_connection_type() > 0) {
                node_component_vector.push_back((circuit_incidence_matrix.matrix_data)[(i - 1) * edge_count + (j - 1)]);
            }
        }
        //get number of components connected to node
        size_t node_component_count{ node_component_vector.size() };
        //adjust total component count for whole circuit
        component_count += node_component_count;
        //adjust total impedance for series or parallel connections
        if (node_component_count > 1 && component_count == edge_count) {
            std::complex<double> node_impedance;
            for (size_t n{ 0 }; n < node_component_count; n++) {
                node_impedance += 1. / node_component_vector[n]->get_impedance();
            }
            temp_impedance += 1. / node_impedance;
        } else if (node_component_count == 1) {
            temp_impedance += node_component_vector[0]->get_impedance();
        }
    }
    total_impedance = std::move(temp_impedance);
}

void circuit::step_into(int node_index, int edge_index)
//function to step into parallel branch 
{
    in_branch = true;
    position = (node_index - 1) * (edge_count)+(edge_index - 1);
}
void circuit::step_out() 
//function that steps out of parallel branch, back onto the level of the original node
{
    in_branch = false;
    position = (node_count - 2) * edge_count + (edge_count - 1);
}

void circuit::add_series(component* component_in_series_out) 
//function that adds components in series and outputs relevant information in the process
//connection type of added component is set to outgoing and frequency is set
{
    component_in_series_out->set_connection_type(1);
    component_in_series_out->set_frequency(ac_circuit_frequency);
    //clone is made of base class component pointer, so that the connection type can be set to incoming (-ve)
    component* component_in_series_in = component_in_series_out->clone();
    component_in_series_in->set_connection_type(-1);
    //print out information of added component
    component_in_series_out->print_component_information();
    if (in_branch == false) {
        //temporary matrix made to be able to increment the incidence matrix as components are added
        matrix temp_matrix{ node_count + 1,edge_count + 1 };
        for (size_t i{ 1 }; i <= node_count; i++) {
            for (size_t j{ 1 }; j <= edge_count; j++)
                //existing components are brought into the new matrix
                temp_matrix.matrix_data[(i - 1) * (edge_count + 1) + (j - 1)] = circuit_incidence_matrix.matrix_data[(i - 1) * edge_count + (j - 1)];
        }
        //moving data has finished, so the dimensions of the circuit matrix are updated
        node_count += 1;
        edge_count += 1;
        //current position in matrix is updated and outgoing and incoming components are added to the temporary matrix
        position = ((node_count - 2) * edge_count + (edge_count - 1));
        temp_matrix.matrix_data[position] = component_in_series_out;
        temp_matrix.matrix_data[position + edge_count] = component_in_series_in;
        //move assignment operator is then used to efficiently take the temporary matrix attributes
        circuit_incidence_matrix = std::move(temp_matrix);
    }
    else {
        //parallel case doesn't require incrementing of the matrix in this implementation
        circuit_incidence_matrix.matrix_data[position] = component_in_series_out;
        circuit_incidence_matrix.matrix_data[position + edge_count] = component_in_series_in;
    }
    //updated incidence matrix is outputted
    std::cout << circuit_incidence_matrix << std::endl;
}

void circuit::add_branches(int n_branches)
//function to add parallel branches to incidence matrix
{
    matrix temp_matrix{ node_count + 1,edge_count + n_branches };
    for (size_t i{ 1 }; i <= node_count; i++) {
        for (size_t j{ 1 }; j <= edge_count; j++)
            temp_matrix.matrix_data[(i - 1) * (edge_count + n_branches) + (j - 1)] = circuit_incidence_matrix.matrix_data[(i - 1) * edge_count + (j - 1)];
    }
    //dimensions of actual incidence matrix are updated after moving the data over to the temporary matrix
    node_count += 1;
    edge_count += n_branches;
    //move assignment operator is then used to efficiently take the temporary matrix attributes
    circuit_incidence_matrix = std::move(temp_matrix);
    std::cout << circuit_incidence_matrix;
}

void circuit::print_library()
//print out of component library using overloaded << for components, with reactance/resistance outputted
{
    int count{ 0 };
    for (auto component_iterator = component_library.begin();
        component_iterator < component_library.end();
        ++component_iterator) {
        std::cout << "i = " << count << ": " << (*component_iterator)->get_name() << "{" << (*component_iterator)->get_reactance() << "}" << std::endl;
        count += 1;
    }
}

void circuit::construct_series() 
//function to construct a series circuit from user input
{
    //vector to store allowed indices of libary + finish keyword to exit loop
    std::vector<std::string> indices_finish_vector;
    for (int n{ 0 }; n < component_library.size(); ++n) {
        indices_finish_vector.push_back(std::to_string(n));
    }
    indices_finish_vector.push_back("finish");
    std::string user_input;
    std::cout << "Please enter the indices of the components which you want to add to the circuit" << std::endl;
    std::cout << "When you have finished, enter 'finish'." << std::endl;
    bool proceed{ true };
    int component_count{ 1 };
    //enter user input loop until finish keyword is used
    while (proceed == true) {
        std::cout << "Component " << component_count << ": ";
        user_input = checker_loop(indices_finish_vector);
        if (user_input == "finish") {
            proceed = false;
        } else {
        add_series(component_library[std::stoi(user_input)]);
        component_count += 1;
        }
    }
}

void circuit::construct_parallel() 
//function to construct parallel series with user input
{
    //construct vector of indices corresponding to library
    std::vector<std::string> indices_vector;
    for (int n{ 0 }; n < component_library.size(); ++n) {
        indices_vector.push_back(std::to_string(n));
    }
    std::string user_input;
    std::cout << "Please enter the number of parallel branches which you want to add to the circuit" << std::endl;
    getline(std::cin, user_input);
    //lower limit to number of branches
    while (std::stoi(user_input) < 2) {
        std::cout << "Your parallel circuit must have more than two branches" << std::endl;
        std::cout << "Please enter the number of branches again" << std::endl;
        getline(std::cin, user_input);
    }
    add_branches(std::stoi(user_input));
    std::cout << "Please enter the indices of the components which you want to add to the circuit" << std::endl;
    int component_count{ 1 };
    //adjust position to add component
    for (int i{ 1 }; i <= get_edge_count(); i++) {
        step_into(1, i);
        std::cout << "Component " << component_count << ": ";
        user_input = checker_loop(indices_vector);
        add_series(component_library[std::stoi(user_input)]);
        component_count += 1;
    }
}

component* circuit::map_to_component(std::string component_type, double magnitude_impedance)
//function to return derived class object, using a map container and cloning
{
    //map from component type input to symbol output initialised
    std::map <std::string, std::string> component_symbol_map;
    component_symbol_map.insert(std::make_pair("resistor", "R"));
    component_symbol_map.insert(std::make_pair("capacitor", "C"));
    component_symbol_map.insert(std::make_pair("inductor", "L"));
    //map from string to default constructed component pointer initialised
    std::map <std::string, component*> component_map;
    component* component_pointer;
    component_map.insert(std::make_pair("resistor", component_pointer = new resistor));
    component_map.insert(std::make_pair("capacitor", component_pointer = new capacitor));
    component_map.insert(std::make_pair("inductor", component_pointer = new inductor));
    //iterate through map to find input component type
    std::map <std::string, component*> ::const_iterator map_iterator = component_map.find(component_type);
    if (map_iterator == component_map.end()) {
        //validation stops this case occuring
        std::cout << "String not found in map." << std::endl;
    } else {
        //new component pointer initialised by cloning second part of map object
        component* component_pointer{ (map_iterator->second)->clone() };
        //stringstream created and component symbol inserted along with libary component count from circuit
        std::stringstream component_name;
        component_name << component_symbol_map[component_type];
        component_name << component_counts[component_type];
        component_counts[component_type]++;
        //name and reactance of component pointer set before being returned to user validation
        component_pointer->set_name(component_name.str());
        component_pointer->set_reactance(magnitude_impedance);
        return component_pointer;
    }
}

void circuit::set_user_library()
//function with user validation to construct library of components
{
    print_line();
    std::vector<std::string> component_name_vector{ "resistor","capacitor","inductor" };
    bool proceed{ true };
    std::cout << "Please specify the components and their associated resistance/capacitance/inductance" << std::endl;
    std::cout << "that you wish to add to your library. When you have finished," << std::endl;
    std::cout << "type 'finish' to finish building your component library. The " << std::endl;
    std::cout << "required format is: component{resistance/capacitance/inductance}. For " << std::endl;
    std::cout << "example: resistor{3.1}, capacitor{2.6} or inductor{3.8}." << std::endl;
    print_line();
    while (proceed == true) {
        std::string user_input;
        std::cout << "Component " << (component_library.size() + 1) << ":" << std::endl;
        std::string component_type;
        std::string magnitude_impedance_str;
        getline(std::cin, user_input);
        if (user_input == "finish") {
            proceed = false;
        } else {
            //declare error flags to be caught
            const int empty_answer_flag{ -1 };
            const int numeric_component_flag{ -2 };
            const int incorrect_closure_flag{ -3 };
            const int unknown_component_flag{ -4 };
            const int empty_impedance_flag{ -5 };
            const int forbidden_impedance_flag{ -6 };
            const int zero_impedance_flag{ -7 };
            int error_holder{ 1 };
            //use stringstream to validate user input
            std::stringstream ss{ user_input };
            getline(ss, component_type, '{');
            getline(ss, magnitude_impedance_str, '}');
            while (error_holder == 1) {
                try {
                    if (user_input.empty()) {
                        throw empty_answer_flag;
                    } if (std::string::npos != component_type.find_first_of("0123456789")) {
                        throw numeric_component_flag;
                    } if (user_input.back() != '}') {
                        throw incorrect_closure_flag;
                    } if (checker(component_type, component_name_vector) == false) {
                        throw unknown_component_flag;
                    } if (magnitude_impedance_str.empty()) {
                        throw empty_impedance_flag;
                    } if (std::string::npos != magnitude_impedance_str.find_first_not_of(".0123456789")) {
                        throw forbidden_impedance_flag;
                    }
                    double magnitude_impedance{ std::stod(magnitude_impedance_str) };
                    if (magnitude_impedance == 0) {
                        throw zero_impedance_flag;
                    } else {
                        //no errors, exit while
                        component_library.push_back(map_to_component(component_type, magnitude_impedance));
                        error_holder = 0;
                        print_line();
                        print_line();
                    }
                }
                catch (int error_flag) {
                    if (error_flag == empty_answer_flag) {
                        std::cout << "Please make sure to enter something." << std::endl;
                    }if (error_flag == numeric_component_flag) {
                        std::cout << "Please make sure your impedance values are after the '{'." << std::endl;
                    } if (error_flag == incorrect_closure_flag) {
                        std::cout << "Please make sure you close with a '}'" << std::endl;
                    } if (error_flag == unknown_component_flag) {
                        std::cout << "Please make sure you specify a component type from:" << std::endl;
                        for (auto component_name_iter = component_name_vector.begin();
                            component_name_iter < component_name_vector.end();
                            ++component_name_iter) {
                            std::cout << *component_name_iter << std::endl;
                        }
                    } if (error_flag == empty_impedance_flag) {
                        std::cout << "You must enter an impedance value" << std::endl;
                    } if (error_flag == forbidden_impedance_flag) {
                        std::cout << "Please ensure your entered resistance/capacitcance/inductance is numerical and positive" << std::endl;
                    } if (error_flag == zero_impedance_flag) {
                        std::cout << "Your component must not have zero resistance/capacitcance/inductance" << std::endl;
                    }
                    //new user input called, following specified error flag
                    std::cout << "Please enter a new component." << std::endl;
                    print_line();
                    std::cin.clear();
                    ss.clear();
                    user_input.clear();
                    component_type.clear();
                    getline(std::cin, user_input);
                    std::stringstream ss{ user_input };
                    getline(ss, component_type, '{');
                    getline(ss, magnitude_impedance_str, '}');
                }
            }
        }
    }
}
