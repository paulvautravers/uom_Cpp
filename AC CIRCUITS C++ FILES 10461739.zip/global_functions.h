//A.C. Analogue Circutis; OOP C++; Paul Vautravers
//global_functions.h
//Simple header file containing functions that support the main code and class definitions

//header guard
#ifndef GLOBAL_FUNCTIONS
#define GLOBAL_FUNCTIONS
//C++ standard library header files
#include<string>
#include<vector>
//declaration of global functions
void print_line();
bool checker(std::string s, std::vector<std::string> str_vec);
std::string checker_loop(std::vector<std::string> allowed_answers);
#endif