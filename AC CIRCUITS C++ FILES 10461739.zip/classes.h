//A.C. Analogue Circuits; OOP C++; Paul Vautravers
//classes.h
//header file containing class and global functions declarations

//header guard
#ifndef CLASSES_H
#define CLASSES_H
//C++ standard library header files
#include <iostream>
#include <complex>
#include <map>

class component
{
protected:
	std::string component_name{};
	double reactance{ 0 };
	std::complex<double> impedance{};
	double frequency{};
	int connection_type{ 0 };
	virtual component* do_clone() const = 0;
public:
	//default and parameterised constructors
	component() {};
	component(double input_reactance, std::string comp_name) :
		reactance{ input_reactance }, component_name{ comp_name }{};
	virtual ~component() {};
	//setter and getter functions
	//names
	void set_name(std::string component_name_input) { component_name = component_name_input; };
	std::string get_name() { return component_name; };
	//reactance and impedance
	void set_reactance(double reactance_input) { reactance = reactance_input; }
	double get_reactance() { return reactance; }
	std::complex<double> get_impedance() { return impedance; }
	double get_magnitude_impedance() { return std::abs(impedance); }
	double get_phase_impedance() { return std::arg(impedance); }
	//frequency
	virtual void set_frequency(double input_component_frequency) = 0;
	double get_frequency() { return frequency; }
	//connection type
	void set_connection_type(int conn_type);
	int get_connection_type() { return connection_type; };
	//clone function for copies of base class pointers
	component* clone() const { return do_clone(); }
	//functions to output/display components
	void print_component_information();
	friend std::ostream& operator<<(std::ostream& out, const component& other_component);
};

class resistor : public component
{
protected:
	virtual resistor* do_clone() const {
		return new resistor(*this);
	}
public:
	resistor() {};
	resistor(double resistance_input, std::string resistor_name) :
		component{ resistance_input,resistor_name } {};
	resistor* clone() const { return do_clone(); }
	void set_frequency(double frequency_input);
};

class capacitor : public component
{
protected:
	virtual capacitor* do_clone() const {
		return new capacitor(*this);
	}
public:
	capacitor() {};
	capacitor(double capacitive_reactance_input, std::string capacitor_name) :
		component{ capacitive_reactance_input, capacitor_name } {};
	capacitor* clone() const { return do_clone(); }
	void set_frequency(double frequency_input);
};

class inductor : public component
{
protected:
	virtual inductor* do_clone() const {
		return new inductor(*this);
	}
public:
	inductor() {};
	inductor(double inductive_reactance_input, std::string inductor_name) :
		component{ inductive_reactance_input, inductor_name } {};
	inductor* clone() const { return do_clone(); }
	void set_frequency(double frequency_input);
};

class matrix
{
public:
	//member data
	component** matrix_data{ nullptr };
	size_t m_rows{};
	size_t n_columns{};
	//default and parameterised constructor, destructor
	matrix() = default;
	matrix(const size_t rows_in, const size_t columns_in);
	~matrix() { delete[] matrix_data; }
	//move assignment
	matrix& operator=(matrix&&) noexcept;
	//misc functions
	component** get_data(){return matrix_data;}
	size_t length() const { return m_rows * n_columns; }
	//friend functions
	friend size_t find_max_width(const matrix& other_matrix);
	friend std::ostream& operator<<(std::ostream& out, const matrix& other_matrix);
};

class circuit : public matrix
//circuit class inherits from matrix class; 
//circuit can be treated as a graph, which is representable as a matrix
{
protected:
	matrix circuit_incidence_matrix;
	size_t node_count{ 1 };
	size_t edge_count{ 0 };
	size_t position{ 0 };
	bool in_branch{ false };
	std::map <std::string, int> component_counts{
		{"resistor",1},{"capacitor", 1},{"inductor", 1}
	};
	std::complex<double> total_impedance{};
	double ac_circuit_frequency{ 50 };
	std::vector<component*> component_library;
public:
	//default and parameterised constructors, overwritten destructor
	circuit() {};
	circuit(double frequency_in, size_t nodes, size_t edges) :
		ac_circuit_frequency{ frequency_in }, node_count{ nodes },
		edge_count{ edges }, circuit_incidence_matrix{ nodes, edges } {};
	~circuit();
	//component library supporting functions
	void set_default_library();
	void set_user_library();
	component* map_to_component(std::string component_type, double magnitude_impedance);
	void print_library();
	//circuit constructing functions
	void add_series(component* component_in_series);
	void add_branches(int n_branches);
	void step_into(int node_index, int branch_index);
	void step_out();
	void construct_series();
	void construct_parallel();
	//setters and getters
	void set_total_impedance();
	std::complex<double> get_total_impedance() { return total_impedance; };
	double get_total_impedance_magnitude() { return std::abs(total_impedance); };
	double get_total_impedance_phase(){ return std::arg(total_impedance); };
	size_t get_node_count() { return node_count; }
	size_t get_edge_count() { return edge_count; }
	void set_frequency(double frequency) { ac_circuit_frequency = frequency; }
	double get_frequency() { return ac_circuit_frequency; }
};
#endif