//A.C. Analogue Circuits; OOP C++; Paul Vautravers
//main.cpp
//Program to allow a user to construct simple series or parallel 
//circuits, using an approach adapted from graph theory. Incidence 
//matrices are outputted as circuits are constructed, and the total 
//circuit impedance is calculated at the end.

//include headers from standard library
#include<complex>
#include<iostream>
#include<vector>
#include<string>
#include<cmath>
#include<sstream>
#include<iomanip>
#include<numeric>
#include<math.h> 
//include headers built for this project
#include"global_functions.h"
#include"classes.h"

int main()
{
    //vector of allowed answers initialised
    std::vector<std::string> simple_allowed_answers{ "0","1" };
    //circuit initialised
    circuit test_circuit;
    std::cout << "This program allows a user to construct a simple series or parallel A.C. circuit." << std::endl;
    std::cout << "As you construct your circuit, an incidence matrix corresponding to the directed" << std::endl;
    std::cout << "graph of your circuit will be outputted to the terminal along with information" << std::endl;
    std::cout << "regarding the component you have added, followed by the total impedance of the" << std::endl;
    std::cout << "circuit at the end." << std::endl;
    print_line();
    std::cout << "Do you want to create a new component library or use a default version" << std::endl;
    std::cout << "in order to construct your circuit?" << std::endl;
    std::cout << "Enter 0 or 1 to use a default or new library respectively." << std::endl;
    //validate for allowed user input
    std::string user_input{ checker_loop(simple_allowed_answers) };
    switch(std::stoi(user_input)){
        case 0:
            test_circuit.set_default_library();
            break;
        case 1:
            test_circuit.set_user_library();
            break;
    }
    print_line();
    //output of default or user constructed library
    std::cout << "The component symbols R, C and L represent resistors, capacitors and inductors" << std::endl;
    std::cout << "respectively. R2, for example, then indicates resistor two of the library." << std::endl;
    std::cout << "These are the components you may build your circuit with:" << std::endl;
    test_circuit.print_library();
    print_line();
    std::cout << "Before constructing your circuit, the frequency of your circuit's voltage input must be specified." << std::endl;
    std::cout << "Please specify the A.C. frequency (rad/s) of the circuit you wish to create." << std::endl;
    getline(std::cin, user_input);
    //validation for physical circuit frequency
    while (!std::stod(user_input) || std::stod(user_input)<=0) {
        std::cout << "The frequency of the circuit must be numerical and greater than zero." << std::endl;
        getline(std::cin, user_input);
    }
    //frequency of whole circuit is set, applied to individual components as added
    test_circuit.set_frequency(std::stod(user_input));
    print_line();
    //user may decided between a series or parallel circuit
    std::cout << "Do you want to create a series or a parallel circuit?" << std::endl;
    std::cout << "Enter 0 or 1 for a series or a parallel circuit respectively." << std::endl;
    user_input = checker_loop(simple_allowed_answers);
    print_line();
    switch (std::stoi(user_input)) {
    case 0:
        test_circuit.construct_series();
        break;
    case 1:
        test_circuit.construct_parallel();
        break;
    }
    print_line();
    print_line();
    //total circuit impedance set
    test_circuit.set_total_impedance();
    //call of circuit properties
    std::cout << "Your circuit has properties:" << std::endl;
    std::cout << "Frequency: " << test_circuit.get_frequency() << " Radians per second" << std::endl;
    std::cout << "Magnitude of Impedance: " << test_circuit.get_total_impedance_magnitude() << " Ohms" << std::endl;
    std::cout << "Phase : " << test_circuit.get_total_impedance_phase() << " Radians" << std::endl;
    print_line();
    print_line();
    return 0;
}
