//A.C. Analogue Circuits; OOP C++; Paul Vautravers;
//global_functions.cpp
//Simple cpp file defining functions that support the main code and class definitions

//C++ standard library header files
#include<iostream>
#include<string>
#include<vector>

void print_line()
//function to output line to break up console output
{
    std::cout << "----------------------------------------------------------------------------";
    std::cout << "-------------------------------" << std::endl;
}

bool checker(std::string s, std::vector<std::string> str_vec)
//bool to check if an element is present in a vector
{
    if (std::find(str_vec.begin(), str_vec.end(), s) != str_vec.end()) {
        return true;
    }
    else { return false; }
}

std::string checker_loop(std::vector<std::string> allowed_answers)
//application of checker function, takes user input and compares to vector of allowed answers
{
    std::string user_input;
    getline(std::cin, user_input);
    while (checker(user_input, allowed_answers) == false) {
        std::cin.clear();
        user_input.clear();
        std::cout << "Please enter a new answer from the allowed answers." << std::endl;
        getline(std::cin, user_input);
        checker(user_input, allowed_answers);
    }
    return user_input;
}